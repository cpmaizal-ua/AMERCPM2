<?php

include __DIR__ . '/vendor/autoload.php';

use GuzzleHttp\Client;
use GuzzleHttp\Promise\Utils;

class CPMNuker {
    private $auth_token;

    public function __construct($auth_token = null) {
        $this->auth_token = $auth_token;
    }

    private function sendRequest($url, $payload, $headers, $params = []) {
        $ch = curl_init();
        $url = $url . '?' . http_build_query($params);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        if (!$response) {
            return null;
        }
        curl_close($ch);
        return json_decode($response, true);
    }

    public function account_login($email, $password) {
        $url = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword";
        $payload = [
            "clientType" => "CLIENT_TYPE_ANDROID",
            "email" => $email,
            "password" => $password,
            "returnSecureToken" => true
        ];
        $headers = [
            "User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; SM-A025F Build/SP1A.210812.016)",
            "Content-Type: application/json"
        ];
        $params = ["key" => "AIzaSyCUKYIK6k_rf6lCmqazuJ2upK3sH5AR4p8"];
        $response_decoded = $this->sendRequest($url, $payload, $headers, $params);

        if (isset($response_decoded["idToken"])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "auth" => $response_decoded["idToken"]
            ];
        } else {
            $error = $response_decoded["error"]["message"];
            $error_code = match($error) {
                "EMAIL_NOT_FOUND" => 100,
                "INVALID_PASSWORD" => 101,
                "MISSING_PASSWORD" => 106,
                "INVALID_EMAIL" => 107,
                "MISSING_EMAIL" => 108,
                default => 404
            };
            return [
                "ok" => false,
                "error" => $error_code,
                "message" => $error,
                "auth" => null
            ];
        }
    }

    public function account_register($email, $password) {
        $url = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser";
        $payload = [
            "email" => $email,
            "password" => $password,
            "clientType" => "CLIENT_TYPE_ANDROID"
        ];
        $headers = [
            "User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; SM-A025F Build/SP1A.210812.016)",
            "Content-Type: application/json"
        ];
        $params = ["key" => "AIzaSyCUKYIK6k_rf6lCmqazuJ2upK3sH5AR4p8"];
        $response_decoded = $this->sendRequest($url, $payload, $headers, $params);

        if (isset($response_decoded["idToken"])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "auth" => $response_decoded["idToken"]
            ];
        } else {
            $error = $response_decoded["error"]["message"];
            $error_code = match($error) {
                "EMAIL_EXISTS" => 105,
                "MISSING_PASSWORD" => 106,
                "INVALID_EMAIL" => 107,
                "MISSING_EMAIL" => 108,
                default => 404
            };
            return [
                "ok" => false,
                "error" => $error_code,
                "message" => $error,
                "auth" => null
            ];
        }
    }

    private function account_info() {
        $url = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/getAccountInfo";
        $payload = [
            "idToken" => $this->auth_token
        ];
        $headers = [
            "User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; SM-A025F Build/SP1A.210812.016)",
            "Content-Type: application/json"
        ];
        $params = ["key" => "AIzaSyCUKYIK6k_rf6lCmqazuJ2upK3sH5AR4p8"];
        $response_decoded = $this->sendRequest($url, $payload, $headers, $params);

        if (isset($response_decoded['kind'])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $response_decoded
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_delete() {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/DeleteAccount4_AppI";
        $payload = ["data" => null];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result'])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    // public function account_clone($to_email, $to_password) {
    //     $from_data = $this->account_get_data()['data'];
    //     $from_cars = $this->account_get_cars()['data'];
    //     $from_id = $from_data['localID'];
    //     $login_status = $this->account_login($to_email, $to_password);
    //     if ($login_status['ok']) {
    //         $this->auth_token = $login_status['auth'];
    //         $to_data = [];
    //         $to_id = strtoupper(substr(str_shuffle(md5(microtime())), 0, 8));
    //         unset($to_data['allData']);
    //         $to_data['Name'] = "NewPlayer69";
    //         $to_data['LocalID'] = $to_id;
    //         $this->account_set_data(json_encode($to_data));
    //         $modified_cars = [];
    //         foreach ($from_cars as $car) $modified_cars[] = json_decode(str_replace($from_id, $to_id, json_encode($car)), true);
    //         $this->account_set_cars($modified_cars);
    //     }
    //     return [
    //         "ok" => $login_status['ok'],
    //         "error" => $login_status['error'],
    //         "message" => $login_status['message']
    //     ];
    // }

    public function save_wallet_money($amount) {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/SaveWalletData4_AppI";
        $payload = [
            "data" => "{\"Money\":$amount}"
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded["result"]) && $response_decoded["result"] === "{\"Result\":1}") {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function save_wallet_coins($amount) {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/SaveWalletData4_AppI";
        $payload = [
            "data" => "{\"Coins\":$amount}"
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded["result"]) && $response_decoded["result"] === "{\"Result\":1}") {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_set_data($content) {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/SavePlayerRecords4_AppI";
        $payload = [
            "data" => $content
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded["result"]) && str_contains($response_decoded["result"], "\"Result\":1")) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_get_data() {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/GetPlayerRecords4_AppI";
        $payload = ["data" => null];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result'])) {
            $data = json_decode($response_decoded['result'], true);
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $data
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_set_rank() {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/SetUserRating4_AppI";
        $data = [
            "RatingData" => [
                "time" => 10000000000,
                "cars" => 100000,
                "car_fix" => 100000,
                "car_collided" => 100000,
                "car_exchange" => 100000,
                "car_trade" => 100000,
                "car_wash" => 100000,
                "slicer_cut" => 100000,
                "drift_max" => 100000,
                "drift" => 100000,
                "cargo" => 100000,
                "delivery" => 100000,
                "race_win" => 3000,
                "taxi" => 100000,
                "levels" => 100000,
                "gifts" => 100000,
                "fuel" => 100000,
                "offroad" => 100000,
                "speed_banner" => 100000,
                "reactions" => 100000,
                "police" => 100000,
                "run" => 100000,
                "real_estate" => 100000,
                "t_distance" => 100000,
                "treasure" => 100000,
                "block_post" => 100000,
                "push_ups" => 100000,
                "burnt_tire" => 100000,
                "passanger_distance" => 100000
            ]
        ];
        $payload = [
            "data" => json_encode($data)
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded["result"])) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_get_cars(){
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/GetAllCars4_AppI";
        $payload = ["data" => null];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded['result'])) {
            $data = json_decode($response_decoded['result'], true);
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL",
                "data" => $data
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR",
                "data" => []
            ];
        }
    }

    public function account_delete_friends() {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/SaveFriends4_AppI";
        $payload = [
            "data" => "{\"FriendsID\":[]}"
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        if (isset($response_decoded["result"]) && str_contains($response_decoded["result"], "\"Result\":1")) {
            return [
                "ok" => true,
                "error" => 0,
                "message" => "SUCCESSFUL"
            ];
        } else {
            return [
                "ok" => false,
                "error" => 404,
                "message" => "UNKNOWN_ERROR"
            ];
        }
    }

    public function account_set_car($data) {
        $url = "https://us-central1-cpm-2-7cea1.cloudfunctions.net/SaveCar4_AppI";
        $payload = [
            "data" => $data
        ];
        $headers = [
            "User-Agent: okhttp/3.12.13",
            "Authorization: Bearer {$this->auth_token}",
            "Content-Type: application/json"
        ];
        $response_decoded = $this->sendRequest($url, $payload, $headers);

        return [
            "ok" => true,
            "error" => 0,
            "message" => "SUCCESSFUL"
        ];
    }

    public function account_set_cars($data) {
        $client = new Client();
        $promises = [];
        foreach ($data as $car) {
            $promises[] = $client->postAsync('https://us-central1-cpm-2-7cea1.cloudfunctions.net/SaveCar4_AppI', [
                'headers' => [
                    "User-Agent" => "okhttp/3.12.13",
                    "Authorization" => "Bearer " . $this->auth_token,
                    "Content-Type" => "application/json"
                ],
                'body' => json_encode(["data" => json_encode($car)]),
            ]);
        }
        $results = Utils::settle($promises)->wait();
    }

    public function unlock_cars() {
        $localId = (string)$this->account_get_data()['data']['PlayerStorage']['LocalID'];
        $jsonFile = file_get_contents("../json/cars.json");
        $jsonData = str_replace("[LOCALID]", $localId, $jsonFile);
        $carsdata = json_decode($jsonData, true);
        $this->account_set_cars($carsdata);
        return [
            "ok" => true,
            "error" => 0,
            "message" => "SUCCESSFUL"
        ];
    }

    public function account_clone($to_email, $to_password) {
        $from_data = $this->account_get_data()['data'];
        $from_cars = $this->account_get_cars()['data'];
        $from_id = $from_data['PlayerStorage']['localID'];
        $login_status = $this->account_login($to_email, $to_password);
        if ($login_status['ok']) {
            $this->auth_token = $login_status['auth'];
            $to_data = $from_data;
            $to_id = strtoupper(substr(str_shuffle(md5(microtime())), 0, 8));
            // unset($to_data['allData']);
            // $to_data['Name'] = "NewPlayer69";
            // $to_data['localID'] = $to_id;
            // $this->account_set_data(json_encode($to_data));
            // $modified_cars = [];
            // foreach ($from_cars as $car) $modified_cars[] = json_decode(str_replace($from_id, $to_id, json_encode($car)), true);
            // $this->account_set_cars($modified_cars);
        }
        return [
            "ok" => $login_status['ok'],
            "error" => $login_status['error'],
            "message" => $login_status['message']
        ];
    }

}
