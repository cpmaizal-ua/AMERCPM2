<?php

//  0: SUCCESSFUL
//100: EMAIL_NOT_FOUND
//101: INVALID_PASSWORD
//102: INSUFFICIENT_FUNDS
//103: INVALID_ACCESS_KEY
//104: MISSING_PARAMETERS
//105: EMAIL_EXISTS
//106: MISSING_PASSWORD
//107: INVALID_EMAIL
//108: MISSING_EMAIL
//109: ACCESS_KEY_BLOCKED
//404: UNKNOWN_ERROR

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;
use Slim\Factory\AppFactory;

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/cpmnuker.php';
require __DIR__ . '/database.php';

$app = AppFactory::create();
$base_path = '/v2/api';
$cpm_db = new CPMNukerDB();

function errorCode($code, $msg) {
    return json_encode([
        "ok" => false,
        "error" => $code,
        "message" => "{$msg}"
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function getUserIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

// Add Routing Middleware
$app->addRoutingMiddleware();

// Define Custom Error Handler
$customErrorHandler = function (Request $request, Throwable $exception, bool $displayErrorDetails, bool $logErrors, bool $logErrorDetails, ?LoggerInterface $logger = null) use ($app) {
    if ($logger) {
        $logger->error($exception->getMessage());
    }
    $payload = [
        'error' => 404,
        'message' => 'NOT_FOUND',
        'info' => [
            'error' => $exception->getMessage(),
            'host' => $request->getUri()->getHost(),
            'path' => $request->getUri()->getPath()
        ]
    ];
    $response = $app->getResponseFactory()->createResponse();
    $response->getBody()->write(
        json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
    );

    return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
};

// Add Error Middleware
$errorMiddleware = $app->addErrorMiddleware(true, true, true);
$errorMiddleware->setDefaultErrorHandler($customErrorHandler);

$app->get($base_path . '/', function ($request, $response, $name) {
    $response->getBody()->write("I'm a teapot");
    return $response->withHeader('Content-Type', 'text/plain')->withStatus(418);
});

$app->get($base_path . '/get_key_data', function ($request, $response, $name) {
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;

    if (!$access_key) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $r = $cpm_db->getAccessKeyData($access_key);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/account_login', function (Request $request, Response $response, $args) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_email = $data['account_email'] ?? null;
    $account_password = $data['account_password'] ?? null;

    if (!$access_key || !$account_email || !$account_password) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker();
    $r = $cpm->account_login($account_email, $account_password);
    if($r['ok']) {
        $cpm_db->setCoins($access_key, $service_price);
        $cpm_db->saveLogin($access_key, getUserIP(), $account_email, $account_password);
    }
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/account_register', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_email = $data['account_email'] ?? null;
    $account_password = $data['account_password'] ?? null;

    if (!$access_key || !$account_email || !$account_password) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker();
    $r = $cpm->account_register($account_email, $account_password);
    if($r['ok']) {
        $cpm_db->setCoins($access_key, $service_price);
        $cpm_db->saveLogin($access_key, getUserIP(), $account_email, $account_password);
    }
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json')->withStatus(201);
});

$app->post($base_path . '/account_delete', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_delete();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/get_data', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_get_data();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/set_data', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $odata = $data['data'] ?? null;

    if (!$access_key || !$account_auth || !$odata) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data($odata);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/set_rank', function ($request, $response, $name) {
    $service_price = 6000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_rank();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/set_money', function ($request, $response, $name) {
    $service_price = 4000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $amount = $data['amount'] ?? null;
    
    if (!$access_key || !$account_auth || !$amount) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->save_wallet_money($amount);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/set_id', function ($request, $response, $name) {
    $service_price = 2500;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $localID = $data['id'] ?? null;
    
    if (!$access_key || !$account_auth || !$localID) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"LocalID\":\"$localID\"}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/set_name', function ($request, $response, $name) {
    $service_price = 1000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $name = $data['name'] ?? null;
    
    if (!$access_key || !$account_auth || !$name) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"Name\":\"{$name}\"}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/set_car', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    $car = $data['car'] ?? null;
    
    if (!$access_key || !$account_auth || !$car) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_car($car);
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/unlock_apartments', function ($request, $response, $name) {
    $service_price = 10000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"Other.Homes\":15}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/unlock_slots', function ($request, $response, $name) {
    $service_price = 7000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"Other.Slots\":100}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/unlock_wheels', function ($request, $response, $name) {
    $service_price = 6000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"Wheels\":[73,74,79,88,84,87,97,98,101,90,91,92,107,93,94,89,1,2,3,7,22,16,21,13,20,12,19,17,11,39,38,34,33,69,30,31,25,52,51,53,54,55,56,57,58,59,63,60,62,64,65,66,67,68,70,71,72,75,76,77,78,80,81,82,83,85,86,95,99,96,100,102,103,105,104,106,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210]}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/unlock_equipments', function ($request, $response, $name) {
    $service_price = 9000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"EquipmentsMale.bag\":[0,1,2,3,4],\"EquipmentsMale.beard\":[6,7,8,9,10,11,12,13,14,15,16,17,18,19,1,20],\"EquipmentsMale.cap\":[3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35],\"EquipmentsMale.face\":[0,1],\"EquipmentsMale.glasses\":[0,1,2,3,4,5,6,7,8,9],\"EquipmentsMale.gloves\":[0,1,2,3,4,5],\"EquipmentsMale.hair\":[1,6,7,8,9,10,11,12,13,14,15,16,17,18,19,0],\"EquipmentsMale.mask\":[3,4,5,6,7,8],\"EquipmentsMale.pants\":[0,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21],\"EquipmentsMale.shoes\":[0,9,10,11,12,13,14,15,16,17,18,19,20,8,7,6,5,4,3,2,1],\"EquipmentsMale.top\":[0,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,66,67,64,65],\"EquipmentsFemale.bag\":[0,1,2,3,4],\"EquipmentsFemale.beard\":[],\"EquipmentsFemale.cap\":[3,4,5,6,7,8,9,10,11,12,13],\"EquipmentsFemale.face\":[1,4],\"EquipmentsFemale.glasses\":[0,1,2,3,4,5,6,7,8,9],\"EquipmentsFemale.gloves\":[1],\"EquipmentsFemale.hair\":[3,7,8,9,10],\"EquipmentsFemale.mask\":[3,4,5,6],\"EquipmentsFemale.pants\":[2,0,3,4,5,6,7],\"EquipmentsFemale.shoes\":[0,3,4,5],\"EquipmentsFemale.top\":[1,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,0],\"Other.Animations\":140525854526}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/unlock_brakes', function ($request, $response, $name) {
    $service_price = 5000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"MatTypes\":127,\"Calipers\":124,\"Brakes\":124}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/unlock_cars', function ($request, $response, $name) {
    $service_price = 10000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->unlock_cars();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/maximize_drag_wins', function ($request, $response, $name) {
    $service_price = 6000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    
    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"RacingProgress.RacingClassRecords\":[{\"TimeClass\":13,\"FirstPlace\":1000000,\"SecondPlace\":3,\"ThirdPlace\":0,\"BestTime\":15.05},{\"TimeClass\":12,\"FirstPlace\":1000000,\"SecondPlace\":3,\"ThirdPlace\":0,\"BestTime\":12},{\"TimeClass\":11,\"FirstPlace\":1000000,\"SecondPlace\":3,\"ThirdPlace\":0,\"BestTime\":11},{\"TimeClass\":10,\"FirstPlace\":1000000,\"SecondPlace\":3,\"ThirdPlace\":0,\"BestTime\":10},{\"TimeClass\":9,\"FirstPlace\":1000000,\"SecondPlace\":3,\"ThirdPlace\":0,\"BestTime\":9},{\"TimeClass\":8,\"FirstPlace\":1000000,\"SecondPlace\":3,\"ThirdPlace\":0,\"BestTime\":2.0}]}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/complete_missions', function ($request, $response, $name) {
    $service_price = 6000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;
    
    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }
    
    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_set_data("{\"Other.LevelsDoneTime\":[2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58,2.58]}");
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/get_all_cars', function ($request, $response, $name) {
    $service_price = 0;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_get_cars();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->post($base_path . '/delete_friends', function ($request, $response, $name) {
    $service_price = 2000;

    $data = $request->getParsedBody();
    $params = $request->getQueryParams();

    $access_key = $params['key'] ?? null;
    $account_auth = $data['account_auth'] ?? null;

    if (!$access_key || !$account_auth) {
        $response->getBody()->write(errorCode(104, 'MISSING_PARAMETERS'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    global $cpm_db;
    
    if (!$cpm_db->isExist($access_key)) { // INVALID_ACCESS_KEY ERROR
        $response->getBody()->write(errorCode(103, 'INVALID_ACCESS_KEY'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    } elseif (!$cpm_db->isUnlimited($access_key)) {
        if ($cpm_db->getCoins($access_key) < $service_price) { // INSUFFICIENT_FUNDS ERROR
            $response->getBody()->write(errorCode(102, 'INSUFFICIENT_FUNDS'));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
    } elseif ($cpm_db->isBlocked($access_key)){ // ACCESS_KEY_BLOCKED ERROR
        $response->getBody()->write(errorCode(109, 'ACCESS_KEY_BLOCKED'));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
    }

    $cpm = new CPMNuker($account_auth);
    $r = $cpm->account_delete_friends();
    if($r['ok'] && !$cpm_db->isUnlimited($access_key)) $cpm_db->setCoins($access_key, $service_price);
    $response->getBody()->write(json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    return $response->withHeader('Content-Type', 'application/json');
});

$app->run();
