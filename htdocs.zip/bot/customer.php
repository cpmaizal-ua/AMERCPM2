<?php

require __DIR__ . '/../api/vendor/autoload.php';

use Medoo\Medoo;

class Customer {
	private $database;
	private $telegram_id;
	private $user;

    public function __construct($telegram_id, $free = true) {
        $this->database = new Medoo([
            'type' => 'mysql',
            'host' => 'localhost',
            'database' => 'ethanolo_cpm2nuker',
            'username' => 'ethanolo_cpm2nuker',
            'password' => 'MoOl{Ymf$]T&'
        ]);
		if(!$this->database->has('customers', ['telegram_id' => $telegram_id])){
			$this->database->insert('customers', [
				'coins' => ($free? 1000 : 0),
				'telegram_id' => $telegram_id,
				'access_key' => strtoupper(substr(str_shuffle(MD5(microtime())), 0, 10))
			]);
		}
        $this->user = $this->database->get('customers', '*', ['telegram_id' => $telegram_id]);
    }

	public function getTelegramID() {
		return $this->user['telegram_id'];
	}

	public function getAccessKey() {
		return $this->user['access_key'];
	}

	public function revokeAccessKey() {
		$newAccessKey = strtoupper(substr(str_shuffle(MD5(microtime())), 0, 10));
        $this->database->update('customers', ['access_key' => $newAccessKey], ['telegram_id' => $this->getTelegramID()]);
        return $newAccessKey;
	}

	public function getCredits() {
		return $this->user['coins'];
	}

	public function setCredits($balance, $prefix = "") {
		$this->database->update('customers', ["coins{$prefix}" => $balance], ['telegram_id' => $this->getTelegramID()]);
	}

	public function getIsUnlimited() {
		return $this->user['is_unlimited'];
	}

	public function setIsUnlimited($value) {
		$this->database->update('customers', ["is_unlimited" => $value], ['telegram_id' => $this->getTelegramID()]);
	}

	public function getIsBlocked() {
		return $this->user['is_blocked'];
	}

	public function setIsBlocked($value) {
		$this->database->update('customers', ["is_blocked" => $value], ['telegram_id' => $this->getTelegramID()]);
	}
}
